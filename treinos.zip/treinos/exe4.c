/*
	Name: digiteZeroParaEncerrarExecucao.c
	Author: Gustavo Silva Souza
	Date: 06/03/24 16:48
	Description: programa que continua executando infinitamente enquanto o usu�rio n�o digita o n�mero zero com a aplica��o de fun��o recursiva
*/



//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
short esperarZero();



//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	esperarZero();
}



//sess�o de fun��es
short esperarZero()
{
	int n = 0;
	
	printf("A seguir, digite o n�mero zero: ");
	scanf("%i", &n);
	
	if(n == 0) return 1;
	
	esperarZero();
}
