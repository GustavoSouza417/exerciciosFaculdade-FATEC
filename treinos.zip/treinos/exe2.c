/*
	Name: impressorNumerosParesZeroAteCem.c
	Author: Gustavo Silva Souza
	Date: 06/03/24 16:32
	Description: programa que exibe todos os n�meros pares de zero a cem com a aplica��o de fun��o recursiva
*/



//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
short exibirParesUmAteCem(short);



//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	exibirParesUmAteCem(0);
}



//sess�o de fun��es
short exibirParesUmAteCem(short n)
{
	if(n > 100) return 1;
	
	printf("%i\n", n);
	exibirParesUmAteCem(n + 2);
}
