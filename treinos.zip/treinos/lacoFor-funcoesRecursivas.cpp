//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
short repetir(int);



//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	repetir(10);	
}



//sess�o de fun��es
short repetir(int numeroRepeticoes)
{
	if(numeroRepeticoes == 0) 
		return 1;
	
	printf("%i\n", numeroRepeticoes);
	
	repetir(--numeroRepeticoes);
}
