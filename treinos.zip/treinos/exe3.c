/*
	Name: exibeImperesUmAteNoveNove.c
	Author: Gustavo Silva Souza
	Date: 06/03/24 16:41
	Description: programa que exibe todos os n�meros impares no intervalo de um a 99 com a aplica��o de fun��o recursiva
*/



//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
short exibirNumerosImparesUmAteNoveNove(short);



//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	exibirNumerosImparesUmAteNoveNove(1);
}



//sess�o de fun��es
short exibirNumerosImparesUmAteNoveNove(short numerosImpares)
{
	if(numerosImpares > 99) return 1;
	
	printf("%i\n", numerosImpares);
	
	exibirNumerosImparesUmAteNoveNove(numerosImpares + 2);
}
