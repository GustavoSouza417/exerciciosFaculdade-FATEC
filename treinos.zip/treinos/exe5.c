/*
	Name: mediaAritmeticaDe500Numeros.c
	Author: Gustavo Silva Souza
	Date: 06/03/24 17:01
	Description: programa que calcula a m�dia aritm�tica de 500 n�meros digitados pelo usu�rio
*/



//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
short calcularMediaAritmetica(int);



//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	calcularMediaAritmetica(4);
}



//sess�o de fun��es
short calcularMediaAritmetica(int qtdNumeros)
{
	int n, mediaAritmetica;
	n = media = 0;
	
	if(qtdNumeros == 0) return 1;
	
	printf("N�mero: ");
	scanf("%i", &n);
	
	mediaAritmetica += n / 4;
	
	calcular
}
