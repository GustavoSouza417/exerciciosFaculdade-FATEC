/*
	Name: incrementoAte100.c
	Author: Gustavo Silva Souza
	Date: 06/03/24 16:22
	Description: programa que exibe n�meros de zero a 100 com aplica��o de fun��o recursiva
*/



//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
short exibirZeroCem(short numero);


//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	exibirZeroCem(0);
}



//sess�o de fun��es
short exibirZeroCem(short numero)
{
	if(numero > 100) return 1;
	
	printf("%i\n", numero);
	
	exibirZeroCem(++numero);
}
