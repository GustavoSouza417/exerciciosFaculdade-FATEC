/*
	Name: recursividade.c
	Author: Gustavo Silva Souza
	Date: 06/03/24 10:05
	Description: programa b�sico para a demonstra��o da recursividade de fun��es
*/



//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
int fatorial(int);



//sess�o de vari�veis globais
int fat = 1;



//fun��o principal
int main()
{
	setlocale(LC_ALL, "Portuguese");
	
	int numero = 0;
	
	printf("Digite um n�mero para calcular seu fatorial: ");
	scanf("%i", &numero);
	
	printf("\nResultado: %i", fatorial(numero));
	
	return 0;
}



//sess�o de fun��es
int fatorial(int numero)
{
	if(numero == 1)
	{
		return fat;
	}
	
	fat = fat * numero;
	fatorial(--numero);
}
