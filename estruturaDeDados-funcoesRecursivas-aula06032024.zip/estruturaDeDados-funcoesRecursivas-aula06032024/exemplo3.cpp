//sess�o de bibliotecas
#include <stdio.h>
#include <locale.h>



//sess�o de prototipa��o
int decrementar(int);



//fun��o principal
main()
{
	setlocale(LC_ALL, "Portuguese");
	
	int n = 0;
	
	printf("A seguir, digite um n�mero: ");
	scanf("%i", &n);
	
	decrementar(n);
}



//sess�o de fun��es
int decrementar(int n)
{
	//aplica��o de operador tern�rio dentro da fun��o "printf()"
	printf((n > 1) ? "%i " : "FOGO!!!", n);
	
	if(n == 1) return 1;
	
	decrementar(--n); 
}
