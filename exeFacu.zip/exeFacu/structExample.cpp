//@AsherLucRen
// Utiliza��o de struct e uni�o

#include <stdio.h>
#include <string.h>
#include <locale.h>

// = = = = = = = = = = = = = = = = = = = = =

struct Contato
{
	char nome[40];
	unsigned char telefone[20];
	char email[100];
};

int main()
{
	setlocale(LC_ALL, "portuguese");
	
	// Declara��o da estrutura
	struct Contato contato;
	
	// Grava��o de dados
	puts("_ _ _ _ GRAVA��O DE DADOS _ _ _ _");
	
	printf("\nInsira seu nome: ");
	fgets(contato.nome, 40, stdin);
	
	printf("\nInsira seu telefone: ");
	fgets(contato.telefone, 15, stdin);

	printf("\nInsira seu email: ");
	fgets(contato.email, 100, stdin);	
	
	// Leitura de dados
	puts("_ _ _ _ SA�DA DE DADOS _ _ _ _");
	printf("\nNome: %s", contato.nome);
	printf("\nEmail: %s", contato.email);
	printf("\nTelefone: %s", contato.telefone);
}
