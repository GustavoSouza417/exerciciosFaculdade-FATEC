/*
    Autor: a tría dos broxas
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int main(){
    char nomeDataPossePresidentes[6][2][26] = {
        {"José Sarney",               "1985"},
        {"Fernando Collor de Mello",  "1990"},
        {"Itamar Franco",             "1992"},
        {"Fernando Henrique Cardoso", "1995"},
        {"Luiz Inácio Lula da Silva", "2003"},
        {"Dilma Rousseff",            "2011"}
    };

    int j, ano;
    ano = j = 0;

    struct tm *tempo;
    time_t segundos;
    time(&segundos);
    tempo = localtime(&segundos);
    ano = tempo -> tm_year + 1900;
    
    for(int i = 0; i < 6; i++){
        printf("Nome: %s", nomeDataPossePresidentes[i][j]); j++;
        printf("\nPosse: %s", nomeDataPossePresidentes[i][j]);
        
        if(i == 5) continue;
        
        printf("\nTempo de posse: %i anos", atoi(nomeDataPossePresidentes[i + 1][j]) - atoi(nomeDataPossePresidentes[i][j]));
        printf("\n----------------\n");
        
        j = 0;
    }
    
    printf("\nTempo de posse: 5 anos");
    
    return 0;
}