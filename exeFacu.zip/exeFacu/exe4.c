#include <stdio.h>
#include <locale.h>

//ordena, de forma crescente, os n�meros recebidos na entrada de dados e os exibe
int ordenador(numero1, numero2, numero3){
	
	//numeros diferentes
	if(numero1 > numero2 && numero1 > numero3){
		
	}
	else if(numero1 < numero2 && numero1 < numero3){
		
	}
	else if(numero2 > numero1 && numero2 > numero3){
		
	}
	else if(numero2 < numero1 && numero2 < numero3){
		
	}
	else if(numero3 > numero1 && numero3 > numero2){
		
	}
	else if(numero3 < numero1 && numero3 < numero2){
		
	}
	
	//dois n�meros iguais
	else if(numero1 == numero2 && numero1 > numero3){
		
	}
	else if(numero1 == numero2 && numero1 < numero3){
		
	}
	else if(numero1 == numero3 && numero1 > numero2){
		
	}
	else if(numero1 == numero3 && numero1 < numero2){
		
	}
	else if(numero2 == numero3 && numero2 > numero1){
		
	}
	else if(numero2 == numero3 && numero2 < numero1){
		
	}
	
	//todos iguais
	else if(numero1 == numero2 && numero1 == numero3){
		return 1;
	}
}

int main(){
	//defini��o de idioma
		setlocale(LC_ALL, "Portuguese");
	
	//declara��o de vari�veis
		int numero1, numero2, numero3;
	
	//entrada de dados
		printf("Digite o primeiro n�mero: ");
		scanf("%i", &numero1);
	
		printf("Digite o segundo n�mero: ");
		scanf("%i", &numero2);
		
		printf("Digite o terceiro n�mero: ");
		scanf("%i", &numero3);
		
	//ordena��o de n�meros
		ordenador(numero1, numero2, numero3);
	
	return 0;
}
